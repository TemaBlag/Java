import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Frame3 extends JPanel {
    Icon icon1 = new ImageIcon("D:\\JavaTasks\\lab9\\1.png");
    Icon icon2 = new ImageIcon("D:\\JavaTasks\\lab9\\2.png");
    Icon icon3 = new ImageIcon("D:\\JavaTasks\\lab9\\3.png");
    Frame3() {
        setSize(600, 200);
        setVisible(true);
        setLayout(new FlowLayout());

        ButtonGroup radButGroup = new ButtonGroup();

        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                JRadioButton currButton = (JRadioButton) e.getSource();
                currButton.setIcon(icon1);
            };

            @Override
            public void mouseExited(MouseEvent e) {
                JRadioButton currButton = (JRadioButton) e.getSource();
                currButton.setIcon(icon2);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                JRadioButton currButton = (JRadioButton) e.getSource();
                currButton.setIcon(icon3);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                JRadioButton currButton = (JRadioButton) e.getSource();
                currButton.setIcon(icon1);
            }


        };

        for(int i = 0; i < 8; i++){
            JRadioButton radBut = new JRadioButton();
            radButGroup.add(radBut);
            radBut.setIcon(icon2);
            radBut.addMouseListener(mouseAdapter);
            add(radBut);
        }

    }
}