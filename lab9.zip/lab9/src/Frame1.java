import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Frame1 extends JPanel {
    Frame1() {
        setSize(600, 400);
        setVisible(true);
        setLayout(new BorderLayout());

        JTextArea leftTextArea = new JTextArea();
        leftTextArea.setPreferredSize(new Dimension(200, 200));
        leftTextArea.setToolTipText("Input text");
        leftTextArea.setText("List");
        add(leftTextArea, BorderLayout.WEST);

        JTextArea rightTextArea = new JTextArea();
        rightTextArea.setPreferredSize(new Dimension(200, 200));
        rightTextArea.setToolTipText("Move text");
        rightTextArea.setText("List");
        add(rightTextArea, BorderLayout.EAST);

        JPanel panel = new JPanel(new BorderLayout());


        JButton upBut = new JButton(">");
        upBut.setPreferredSize(new Dimension(150, 50));
        panel.add(upBut, BorderLayout.NORTH);

        JButton downBut = new JButton("<");
        downBut.setPreferredSize(new Dimension(150, 50));
        panel.add(downBut, BorderLayout.SOUTH);

        add(panel, BorderLayout.CENTER);

        upBut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (leftTextArea.getSelectedText() == null){
                        throw new IllegalArgumentException();
                    }
                rightTextArea.append(leftTextArea.getSelectedText());
                leftTextArea.setText(leftTextArea.getText().replace(leftTextArea.getSelectedText(), ""));

            } catch (IllegalArgumentException ex1){
                JOptionPane.showMessageDialog(Frame1.this, "Empty selected text");
            }
            }
        });

        downBut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    if (rightTextArea.getSelectedText() == null){
                        throw new IllegalArgumentException();
                    }
                    leftTextArea.append(rightTextArea.getSelectedText());
                    rightTextArea.setText(rightTextArea.getText().replace(rightTextArea.getSelectedText(), ""));
                } catch (IllegalArgumentException ex1){
                    JOptionPane.showMessageDialog(Frame1.this, "Empty selected text");
                }
            }
        });

    }
}