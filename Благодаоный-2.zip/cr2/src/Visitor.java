public interface Visitor {
    void visit(Integer el);
}
