import java.util.ArrayList;
public interface FilterStrategy {
    Integer cardinality(ArrayList<MyInteger> nums);
}
